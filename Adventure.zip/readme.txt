Note:
- unpack the game before playing
- saves are stored in %localappdata%/Adventure
- spam the doors at your own risk
- smart screen can be ignored - trust me

Controls:
F1              : hard restarts to start menu
F3              : displays debug info (can not be disabled)
F11             : toggles fullscreen
space           : interact / select dialogue option
right arrow     : move dialogue option selection to the right
left arrow      : move dialogue option selection to the left
W / up arrow    : move player up
S / down arrow  : move player down
A / left arrow  : move player left
D / right arrow : move player right

Version 0.1.0.0 (17.01.2022)
The game was made with gml, a simplified mutation of c++, which is used in Game Maker Studio 2.