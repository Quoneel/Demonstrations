Note:
- unpack the game before playing
- smart screen can be ignored

Controls:
W / up arrow    : acceleration forward
S / down arrow  : acceleration backward
A / left arrow  : rotation acceleration left
D / right arrow : rotation acceleration right

Version 0.0.1.0 (6.01.2022)
The game was made with gml, a simplified mutation of c++, which is used in Game Maker Studio 2.