Note:
- CAGE stands for Console Adventure Game Engine
- This is just a personal engine, NOT a game!
- made with C#