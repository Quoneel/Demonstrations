Note:
- you can ignore smart screen
- you can add/remove words from hangmandict.txt

Type characters into the console to guess them.
Made with C#. Finished 06/04/2021.