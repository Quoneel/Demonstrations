Note:
- you can ignore smart screen

Keys:
space  : start game (menu)
enter  : restart to menu
escape : exit game
1      : toggle amount of targets (menu)
2      : toggle target movement level (menu)
3      : toggle target life time (menu)

Click the appearing targets as quickly as you can. After you clicked all targets, your stats will be displayed.

Made with C# in early 2021.