Note:
- smart screen can be ignored
- this is only a cancelled attempt to make an engine for the monoGame Framework

Made with C# in early 2021.