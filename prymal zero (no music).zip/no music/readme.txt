Note that his version has no music du to size issues.

How to run the game:
1. Install python and pip
2. run "pip install pgzero"
3. run "pgzrun {path of the .py file}"

This game was made as a school project. The game is from April 27th 2021.
Read the documentation, it contains a manual.