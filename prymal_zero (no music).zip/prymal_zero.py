from random import *  # importing the random lib

WIDTH = 1500  # setting window size
HEIGHT = 1000
TITLE = "Prymal Zero"

bg = {  # storing background data
    'img': 'title.png',
    'movement': 0,
    'y': 0
}
bgo = {  # storing background overlay data
    'img': 'star_overlay.png',
    'img': 'star_overlay.png',
    'movement': 0,
    'y': 0
}
phase = 'title'  # for game not to start right off
paused = False  # for when you want to pause the game
dialogue = {  # dict for the dialogue system
    'id': '',  # wich text from the "texts" variable is displayed
    'person': '',  # wich picture is shown
    'active': False  # dialogue box visibility
}
texts = {  # variable to store long dialogue texts, to save space
    'pruxys_do_you_copy': '''Mission Control to Agent Snowcom, repeat,
Mission Control to Agent Snowcom! Do you copy?''',
    'pruxys_asteroid_field': '''You are extremely close to the asteroid belt
I warned you about. Do not get hit, or you will be stuck!''',
    'pruxys_keep_the_pace': '''Good, keep the pace.''',
    'pruxys_am_here': '''Yes, I am here. Have you made it through?''',
    'pruxys_no_asteroids': '''It is very unlikely that those are
more asteroids. You may need to engage combat.
I unlocked your cannons just in case... ''',
    'pruxys_be_careful': '''Please, be careful,
this mission is important. Be sure
to make use of your energy-shield.''',
    'pruxys_good_luck': '''Good luck, Agent.''',
    'pruxys_made_what': '''Made what?''',
    'pruxys_could_have_been_worse': '''Dragonflies? Could have been worse...''',
    'pruxys_must_be_hard': '''Is it that bad? You are the best combat pilot
we have! They must be really fast then!''',
    'pruxys_what_do_you_mean': '''What do you mean?''',
    'pruxys_would_explain': '''This would explain a lot''',
    'pruxys_mission': '''This could be connected to whats in the
data you are supposed to exfiltrate.''',
    'pruxys_not_authorized': '''I am currently not authorized to tell you,
but I will ask the Administrators. I will reach you then.''',
    'snowcom_i_hear_you': '''I can hear you, loud and clearly.''',
    'snowcom_ill_keep_an_eye_out': '''Thanks, I will watch out.''',
    'snowcom_are_you_there': '''Control? Can you hear me?''',
    'snowcom_yes_but': '''I'm through. Although my Sensors
are still showing multiple objects
further ahead of me... No life signs.''',
    'snowcom_how_nice': '''You're worried? How nice of you...''',
    'snowcom_made_it': '''Okay, I made it.''',
    'snowcom_dragonflies': '''Dragonflies. The annoying models.''',
    'snowcom_hard_to_hit': '''Do you have the slightest idea, how hard
it is to hit those god damn devils!?''',
    'snowcom_shut_your_speakers': '''Oh, Shut your speakers...''',
    'snowcom_theres_more': '''Shite! There's more of them!''',
    'snowcom_done_for_now': '''Phew! I think that was it. For now...

    (the end)''',
    'snowcom_not_normal': '''Those were not the normal dragonflies!
Not those Omnira infected drones that escaped the Nirai
factory to scare young pilots while training!''',
    'snowcom_harder_better': '''They were harder, better, faster
and stronger. Someone also mounted a second
cannon on them!''',
    'snowcom_some_madman': '''I think someone decided that it
would be a good idea to mod some annoying demons of drones.
''',
    'snowcom_how_even': '''But how would someone even get to
capture those things without them to self-destruct?
Let alone getting past Omnira?''',
    'snowcom_in_wich_way': '''In wich way?''',
    'snowcom_till_later': '''Okay, hear you then, I guess...'''
}
asteroid_belt = []  # list for all the asteroids
asteroid_amount = 100  # amount of asteroids that will be spawned
asteroid_speed = 1.3  # speed of asteroids
enemies = []  # list of enemies and their properties
lasers = {
    'enemies': [],
    'player': []
}
player = {
    'actor': Actor('player.png', (750 - 16, 650 - 16)),  # adding the player
    'health': 50,  # how much the player can take before dying
    'energy': [50, 50, 50],  # player['energy'] amount, max player['energy'], save for old energy amount before reloading
    'speed': 2,
    'comb_speed': 4,
    'damage': 10,
    'laser_speed': 15,
    'reload_time': 0.75,
    'shield': False,
    'shield_amount': [0, 25],
    'control': False,  # if player has control over ship
    'visible': False,
    'flames_visible': True  # wther to show flames
}
player['flame'] = Actor('flame0.png', (player['actor'].x, player['actor']. y - 16))  # the flame of the ship
goals_progress = {  # progress to finish phases in main loop
    'asteroids_dodged': 0,
    'enemies_killed1': 0,
    'enemies_killed2': 0
}

combat = False  # combat mode
energyvis = False  # wether to show player['energy'] amount
healthvis = False
shieldvis = False
border = 10  # how early the player can't move further towards the edge


def update():  # main loop
    global phase, player, combat
    if not paused:  # only update if game is not paused
        bg_update()  # draw background
        if phase == 'title':  # anything that happens in the title screen
            screen.draw.text("Press Any Key", (700, 500))  # showing test on title screen
            screen.draw.text("(Sound On!)", (710, 530))
        if phase == 'asteroids':  # everything happening in the asteroid phase
            asteroid_update()  # calling asteroid movement update function
            if goals_progress['asteroids_dodged'] >= asteroid_amount:
                phase = 'comm2'  # goes into next phase when all asteroids are dodged
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_are_you_there'
                clock.schedule(dialogue_activate, 6)  # start next dialogue
        elif phase == 'enemies':
            if goals_progress['enemies_killed1'] >= 4:
                phase = 'comm3'
                player['speed'] = 3
                combat = False
                player['control'] = False
                start_reload_energy()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_made_it'
                clock.schedule(dialogue_activate, 3)
        elif phase == 'enemies2':
            if goals_progress['enemies_killed2'] >= 6:
                phase = 'comm4'
                player['speed'] = 3
                combat = False
                player['control'] = False
                start_reload_energy()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_done_for_now'
                clock.schedule(dialogue_activate, 3)
        player_update()
        dialogue_update()
        enemy_update()
        laser_update()
        if energyvis:
            screen.draw.text(f"Energy: {player['energy'][0]}/{player['energy'][1]}", (0, 0))
        if healthvis:
            screen.draw.text(f"Health: {player['health']}", (0, 20))
        if shieldvis:
            screen.draw.text(f"Shield: {player['shield_amount'][0]}/{player['shield_amount'][1]}", (0, 40))


def on_key_down(key):  # all single key detections
    if key == keys.ESCAPE:
        global paused
        if paused:
            paused = False
            print('Game Unpaused')
        elif not paused:
            paused = True
            print('Game Paused')  # pause music
            screen.blit('pause.png', (0, 0))  # show pause overlay
            screen.draw.text("Game Paused", (700, 530))  # show 'Game Paused' message
    elif not paused:
        global player, combat, energyvis, shieldvis
        global phase, bg, bgo, dialogue, healthvis
        if phase == 'title':  # begin first dialogue phase
            phase = 'comm1'
            bg['img'] = 'bg.png'
            bg['movement'] = 0.1  # begin background movement
            bgo['movement'] = 0.2  # begin overlay movement
            player['visible'] = True
            player['control'] = False
            dialogue['person'] = 'pruxys_worried.png'
            dialogue['id'] = 'pruxys_do_you_copy'
            clock.schedule(dialogue_activate, 6)
        elif key in [keys.R, keys.LCTRL] and combat and player['energy'][0] != 'reloading' and player['energy'][0] < player['energy'][1]:
            start_reload_energy()
        elif key in [keys.E, keys.LSHIFT] and combat and player['energy'][0] != 'reloading' and player['energy'][0] > 5:
            toggle_shield()
        elif phase == 'comm1':
            if key == keys.SPACE and dialogue['id'] == 'pruxys_do_you_copy' and dialogue['active']:
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_i_hear_you'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_i_hear_you':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_worried.png'
                dialogue['id'] = 'pruxys_asteroid_field'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_asteroid_field':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_ill_keep_an_eye_out'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_ill_keep_an_eye_out':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_happy.png'
                dialogue['id'] = 'pruxys_keep_the_pace'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_keep_the_pace':
                sounds.blip_low.play()
                dialogue['active'] = False
                player['control'] = True
                phase = 'asteroids'
                spawn_asteroids(asteroid_amount)
        elif phase == 'comm2':
            if key == keys.SPACE and dialogue['id'] == 'snowcom_are_you_there' and dialogue['active']:
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_neutral.png'
                dialogue['id'] = 'pruxys_am_here'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_am_here':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_yes_but'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_yes_but':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_neutral.png'
                dialogue['id'] = 'pruxys_no_asteroids'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_no_asteroids':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_worried.png'
                dialogue['id'] = 'pruxys_be_careful'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_be_careful':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_how_nice'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_how_nice':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_blushing2.png'
                dialogue['id'] = 'pruxys_good_luck'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_good_luck':
                sounds.blip_low.play()
                dialogue['active'] = False
                player['control'] = True
                combat = True
                energyvis = True
                healthvis = True
                shieldvis = True
                phase = 'enemies'
                spawn_enemy((50, -40), (50, 80), 5, None, 'dragonfly-b.png', 25)
                spawn_enemy((1450, -40), (1450, 80), 5, None, 'dragonfly-b.png', 25)
                spawn_enemy((100, -40), (100, 80), 5, None, 'dragonfly-b.png', 25)
                spawn_enemy((1400, -40), (1400, 80), 5, None, 'dragonfly-b.png', 25)
                player['speed'] = player['comb_speed']
        elif phase == 'comm3':
            if key == keys.SPACE and dialogue['id'] == 'snowcom_made_it' and dialogue['active']:
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_neutral.png'
                dialogue['id'] = 'pruxys_made_what'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_made_what':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_dragonflies'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_dragonflies':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_neutral.png'
                dialogue['id'] = 'pruxys_could_have_been_worse'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_could_have_been_worse':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom.png'
                dialogue['id'] = 'snowcom_hard_to_hit'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_hard_to_hit':
                sounds.blip_short.play()
                dialogue['person'] = 'pruxys_laughing.png'
                dialogue['id'] = 'pruxys_must_be_hard'
            elif key == keys.SPACE and dialogue['id'] == 'pruxys_must_be_hard':
                sounds.blip_short.play()
                dialogue['person'] = 'dialogue_snowcom'
                dialogue['id'] = 'snowcom_shut_your_speakers'
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_shut_your_speakers':
                sounds.blip_low.play()
                dialogue['active'] = False
                dialogue['person'] = 'dialogue_snowcom'
                dialogue['id'] = 'snowcom_theres_more'
                clock.schedule(dialogue_activate, 3)
            elif key == keys.SPACE and dialogue['id'] == 'snowcom_theres_more' and dialogue['active']:
                phase = 'enemies2'
                spawn_enemy((50, -40), (50, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                spawn_enemy((1450, -40), (1450, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                spawn_enemy((100, -40), (100, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                spawn_enemy((1400, -40), (1400, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                spawn_enemy((150, -40), (150, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                spawn_enemy((1350, -40), (1350, 80), 6, None, 'dragonfly-x.png', 50, 2, 'dragonfly-x')
                player['speed'] = player['comb_speed']
                player['control'] = True
                combat = True
                dialogue['active'] = False


def on_mouse_down(pos, button):
    global player
    if not paused:
        if button == mouse.LEFT:
            player_shoot()


def player_update():
    global player
    if player['control']:  # if player has control
        if keyboard.a or keyboard.left:  # wasd movement
            player['actor'].x -= player['speed']
            if player['actor'].x <= 0 + border:
                player['actor'].x += player['speed']
        if keyboard.d or keyboard.right:
            player['actor'].x += player['speed']
            if player['actor'].x >= 1500 - border:
                player['actor'].x -= player['speed']
        if keyboard.w or keyboard.up:
            player['actor'].y -= player['speed']
            if player['actor'].y <= 0 + border:
                player['actor'].y += player['speed']
        if keyboard.s or keyboard.down:
            player['actor'].y += player['speed']
            if player['actor'].y >= 1000 - border:
                player['actor'].y -= player['speed']
    if player['visible']:  # if player visible visible
        flame_update()  # draw flame
        player['actor'].draw()  # draw player over flame


def laser_update():
    global enemies, player
    for laser in lasers['player']:
        laser[0].y -= player['laser_speed']
        if laser[0].y > -30:
            laser[0].draw()
            for enemy in enemies:
                if laser[0].colliderect(enemy['actor']):
                    enemy['health'] -= player['damage']
                    sounds.tchium.play()
                    try:
                        lasers['player'].remove(laser)
                    except ValueError:
                        pass
        else:
            lasers['player'].remove(laser)
    for laser in lasers['enemies']:
        laser[0].y += 10
        if laser[0].y < 1030:
            laser[0].draw()
            if laser[0].colliderect(player['actor']):
                player_hurt(laser[1])
                lasers['enemies'].remove(laser)
        else:
            lasers['enemies'].remove(laser)


def toggle_shield(toggle=None):
    global player
    old_shield_amount = player['shield_amount'][0]
    if player['energy'][0] != 'reloading' and player['energy'][0] >= 10 and toggle != False:
        if player['shield_amount'][0] > player['shield_amount'][1] - 10:
            player['energy'][0] -= player['shield_amount'][1] - player['shield_amount'][0]
            player['shield_amount'][0] += 10
        else:
            player['energy'][0] -= 10
            player['shield_amount'][0] += 10
        if player['shield_amount'][0] > player['shield_amount'][1]:
            player['shield_amount'][0] = player['shield_amount'][1]
        # activate shield
        player['shield'] = True
        player['actor'].image = 'player_shield.png'
    elif toggle == False:
        player['shield_amount'][0] = 0
        # deactivate shield
        player['shield'] = False
        player['actor'].image = 'player.png'


def player_shoot():
    global lasers
    try:
        if combat and player['energy'][0] >= 5:
            sounds.laser_h.play()
            lasers['player'].append([Actor('purple_laser.png', (player['actor'].x - 10, player['actor'].y - 4))])
            lasers['player'].append([Actor('purple_laser.png', (player['actor'].x + 11, player['actor'].y - 4))])
            player['energy'][0] -= 5
        elif combat and player['energy'][0] < 5:
            sounds.jam.play()
            start_reload_energy()
    except TypeError:
        sounds.jam.play()


def player_hurt(amount):
    global player
    player['shield_amount'][0] -= amount
    if player['shield']:
        sounds.shield_block.play()
    if player['shield_amount'][0] <= 0:
        player['health'] += player['shield_amount'][0]
        toggle_shield(False)
        sounds.tchhh.play()
    if player['health'] <= 0:
        kill_player()


def enemy_shoot(who):
    global lasers
    if who['cooldown'] <= 0:
        if who['type'] == 'dragonfly-x':
            sounds.laser_m.play()
            lasers['enemies'].append([Actor('green_laser.png', (who['actor'].x - 10, who['actor'].y + 3)), 15])
            lasers['enemies'].append([Actor('green_laser.png', (who['actor'].x + 10, who['actor'].y + 3)), 15])
            who['cooldown'] = who['max_cooldown']
        elif who['type'] == 'dragonfly-b':
            sounds.laser_m.play()
            lasers['enemies'].append([Actor('green_laser.png', (who['actor'].x + 5, who['actor'].y + 3)), 10])
            who['cooldown'] = who['max_cooldown']
    else:
        who['cooldown'] -= 1


def flame_update():  # flame animation
    global player, flame
    if player['flames_visible']:
        player['flame'].x = player['actor'].x
        player['flame'].y = player['actor'].y + 26
        player['flame'].image = f'flame{randrange(0, 4)}.png'  # change to random animation frame
        player['flame'].draw()


def bg_update():  # for background and overlay movement
    global bg, bgo
    if bg['y'] < 1000:
        bg['y'] += bg['movement']
    else:
        bg['y'] = 0
    screen.blit(bg['img'], (0, bg['y']))
    screen.blit(bg['img'], (0, bg['y'] - 1000))
    if bgo['y'] < 1000:
        bgo['y'] += bgo['movement']
    else:
        bgo['y'] = 0
    screen.blit(bgo['img'], (0, bgo['y']))
    screen.blit(bgo['img'], (0, bgo['y'] - 1000))


def dialogue_activate():  # had to do this because schedule only supports functions without arguments
    global dialogue, player
    player['control'] = False
    dialogue['active'] = True
    sounds.blip_short.play()


def dialogue_update():  # dialogue system
    global dialogue
    if dialogue['active']:
        screen.blit('dialogue_bar.png', (0, 0))  # draws the dialogue background bar
        screen.blit(dialogue['person'], (0, 0))  # draws the base image of the person speaking
        screen.draw.text(texts[dialogue['id']], (400, 800), fontsize=60)


def spawn_asteroids(amount):  # spawn asteroids far above
    global asteroid_belt
    for i in range(0, amount):
        r = randrange(0, 3)
        if r == 0:  # spawn small asteroid that moves faster, but can also spawn further above
            asteroid_belt.append(Actor(f'asteroid0.png', (randrange(10, 1490), randrange(-16000, -400))))
        elif r == 1:
            asteroid_belt.append(Actor(f'asteroid1.png', (randrange(10, 1490), randrange(-10000, -400))))
        else:  # spawn big asteroid that moves slower. but also spawns closer
            asteroid_belt.append(Actor(f'asteroid2.png', (randrange(10, 1490), randrange(-5000, -400))))


def asteroid_update():  # update function to move all asteroids
    global asteroid_belt, goals_progress
    for asteroid in asteroid_belt:
        if asteroid.image == 'asteroid0.png':
            asteroid.y += 6 * asteroid_speed  # moves slower if it has biggest model
        elif asteroid.image == 'asteroid1.png':
            asteroid.y += 4 * asteroid_speed
        else:
            asteroid.y += 2 * asteroid_speed  # moves faster if it has smallest model
        if asteroid.y >= 1200:
            asteroid_belt.remove(asteroid)
            goals_progress['asteroids_dodged'] += 1
        if asteroid.angle == 0:  # if asteroid hasn't been turned yet
            asteroid.angle = randrange(0, 360)  # turns the asteroid to create diversity
        if asteroid.y >= -200:  # only draw if visible to save resources
            asteroid.draw()
        if asteroid.colliderect(player['actor']):
            kill_player()


def spawn_enemy(pos, dest, speed, bound, image, health, cooldown=5, model='dragonfly-b', prevent_tailspin=False):
    enemies.append({
        'actor': Actor(image, (pos[0], pos[1])),
        'health': health,
        'dest': [dest[0], dest[1]],
        'origin': [pos[0], pos[1]],
        'speed': speed,  # base speed
        'x_speed': speed,
        'y_speed': speed,
        'cooldown': cooldown,
        'max_cooldown': cooldown,
        'type': model,
        'bound': bound,
        'tailspin': 0  # how much the enemy spins while falling
    })
    if enemies[-1]['bound'] is None:
        enemies[-1]['bound'] = (randrange(10, 450), randrange(10, 1490))


def enemy_update():
    global enemies, goals_progress
    for enemy in enemies:
        if enemy['health'] > 0:
            if enemy['origin'][1] < enemy['dest'][1]:
                enemy['actor'].y += enemy['y_speed']
                if enemy['actor'].y >= enemy['dest'][1]:
                    enemy_shoot(enemy)
                    enemy['actor'].y = enemy['dest'][1]
                    enemy['origin'][1] = enemy['actor'].y
                    enemy['dest'][1] = enemy['bound'][0]
                    enemy['y_speed'] = randrange(enemy['speed'], enemy['speed'] * 2)
            elif enemy['origin'][1] > enemy['dest'][1]:
                enemy['actor'].y -= enemy['y_speed']
                if enemy['actor'].y <= enemy['dest'][1]:
                    enemy_shoot(enemy)
                    enemy['actor'].y = enemy['dest'][1]
                    enemy['origin'][1] = enemy['actor'].y
                    enemy['dest'][1] = enemy['bound'][0]
                    enemy['y_speed'] = randrange(enemy['speed'], enemy['speed'] * 2)
            if enemy['origin'][0] < enemy['dest'][0]:
                enemy['actor'].x += enemy['x_speed']
                if enemy['actor'].x >= enemy['dest'][0]:
                    enemy_shoot(enemy)
                    enemy['actor'].x = enemy['dest'][0]
                    enemy['origin'][0] = enemy['actor'].x
                    enemy['dest'][0] = enemy['bound'][1]
                    enemy['x_speed'] = randrange(enemy['speed'], enemy['speed'] * 2)
            elif enemy['origin'][0] > enemy['dest'][0]:
                enemy['actor'].x -= enemy['x_speed']
                if enemy['actor'].x <= enemy['dest'][0]:
                    enemy_shoot(enemy)
                    enemy['actor'].x = enemy['dest'][0]
                    enemy['origin'][0] = enemy['actor'].x
                    enemy['dest'][0] = enemy['bound'][1]
                    enemy['x_speed'] = randrange(enemy['speed'], enemy['speed'] * 2)
            if enemy['origin'][0] == enemy['dest'][0]:
                enemy['dest'][0] = randrange(10, 1490)
            if enemy['origin'][1] == enemy['dest'][1]:
                enemy['dest'][1] = randrange(10, 450)
        if enemy['health'] <= 0:
            if enemy['tailspin'] == 0:
                enemy['tailspin'] = randrange(-20, 20)
            enemy['actor'].angle = enemy['actor'].angle + enemy['tailspin']
            # tailspin effect
            enemy['actor'].y += 7.5
            if enemy['actor'].y > 1100:
                enemies.remove(enemy)
                if phase == 'enemies':
                    goals_progress['enemies_killed1'] += 1
                elif phase == 'enemies2':
                    goals_progress['enemies_killed2'] += 1
        enemy['actor'].draw()


def start_reload_energy():
    global player
    if player['energy'][0] != 'reloading':
        player['energy'][2] = player['energy'][0]
        player['energy'][0] = 'reloading'
        clock.schedule(reload_energy, player['reload_time'])


def reload_energy(amount=10):
    global player
    player['energy'][0] = player['energy'][2] + amount
    if player['energy'][0] > player['energy'][1] or not combat:
        player['energy'][0] = player['energy'][1]
    sounds.powerup_s.play()


def kill_player():
    global player, paused
    paused = 'game_over'
    player['control'] = False
    player['flames_visible'] = False
    game_over()


def game_over():
    screen.blit('title.png', (0, 0))
    screen.draw.text("Game Over!", (640, 480), fontsize=60)
    screen.draw.text("(Restart your game!)", (665, 600))